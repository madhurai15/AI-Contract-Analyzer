# Docket — AI Contract Risk Analyzer

Upload a contract, get every clause segmented and risk-scored, ask it
questions with retrieval-augmented Q&A, and see a Monte Carlo simulation of
your financial exposure instead of one opaque risk number.

## Architecture

```
contract-risk-analyzer/
├── backend/                 FastAPI service
│   ├── app/
│   │   ├── core/config.py           settings (models, paths, thresholds)
│   │   ├── models/schemas.py        Pydantic request/response models
│   │   ├── services/
│   │   │   ├── document_parser.py   PDF/DOCX/TXT -> raw text + page map
│   │   │   ├── clause_extraction.py Legal-BERT embeddings, zero-shot clause typing
│   │   │   ├── risk_scoring.py      rule-augmented risk score per clause
│   │   │   ├── rag_pipeline.py      chunk + embed + ChromaDB retrieval Q&A
│   │   │   └── monte_carlo.py       triangular-distribution exposure simulator
│   │   ├── routers/                 contracts / rag / simulation endpoints
│   │   └── main.py
│   └── Dockerfile
├── frontend/                 React + Vite
│   └── src/
│       ├── components/       UploadZone, ClauseMargin, ClauseDetail,
│       │                     ExposureChart, RagPanel, RiskSummary
│       └── api/client.js
└── docker-compose.yml
```

## How clause classification works

Clause typing is a **hybrid of a fine-tuned classifier and zero-shot
similarity matching**, in `clause_extraction.py`:

- **Fine-tuned path.** For the clause types that have real ground truth in
  the [CUAD dataset](https://www.atticusprojectai.org/cuad) (510 contracts,
  41 expert-labeled clause categories) — `Governing Law`, `Non-Compete`,
  `Limitation of Liability`, `Termination`, `IP Assignment` — a small MLP
  head is trained on top of frozen Legal-BERT embeddings using ~2,600
  CUAD-derived examples. See `scripts/prepare_cuad_data.py` (builds the
  labeled train/val set from the raw CUAD JSON) and
  `scripts/train_clause_classifier.py` (embeds + trains the head).
- **Zero-shot fallback.** CUAD's 41 categories don't cover everything this
  app scores — `Indemnification`, `Confidentiality`, `Payment Terms`,
  `Auto-Renewal`, `Force Majeure`, `Data Protection`, and
  `Dispute Resolution` have no CUAD ground truth at all. These (and anything
  the fine-tuned head is less confident about) still use cosine similarity
  against hand-written prototype descriptions (`CLAUSE_PROTOTYPES`).

Each candidate clause is scored by both paths; whichever is more confident
wins. This is a deliberate design choice, not a limitation glossed over: a
supervised classifier is only as honest as its labels, and CUAD simply
doesn't label every category this app cares about, so a full replacement
of zero-shot would mean silently guessing on 7 of 13 categories with no
ground truth to justify it.

### Reproducing / retraining the fine-tuned head

```bash
cd backend
python scripts/prepare_cuad_data.py --cuad-json data/cuad/CUADv1.json --out data/cuad/prepared
python scripts/train_clause_classifier.py --data data/cuad/prepared --out app/ml_artifacts
```

The first script requires the raw CUAD JSON (`CUADv1.json`, ~39MB, CC BY
4.0), downloadable from the
[CUAD GitHub repo](https://github.com/TheAtticusProject/cuad). The second
requires internet access to Hugging Face to download
`nlpaueb/legal-bert-base-uncased` (~440MB) — the same requirement the app
already has at runtime. Training the head itself is fast (CPU, a few
minutes) since only a small MLP on top of frozen embeddings is trained, not
the full transformer.

If `app/ml_artifacts/` is empty or missing, `ClauseExtractor` falls back to
zero-shot for every category automatically — nothing breaks.

## Differentiators over commercial contract-review tools

- **Monte Carlo exposure simulation** — instead of a single risk score,
  simulates 10,000 possible financial outcomes per clause category and
  reports P50/P90/P99 and worst-case exposure (`monte_carlo.py`).
- **Live what-if redlining** — paste a proposed replacement for any clause
  and see the risk delta immediately, before sending it back to the
  counterparty (`/simulation/what-if`).
- **Transparent, rule-based rationale** — every risk score comes with the
  specific red-flag phrases that drove it, not a black-box number.

## Running locally

### With Docker (recommended)
```bash
docker compose up --build
```
- Backend: http://localhost:8000/docs (Swagger UI)
- Frontend: http://localhost:3000

### Without Docker

**Backend:**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

## First-run note

The first request will download the Legal-BERT model (~440MB) and the
sentence-transformer embedding model (~80MB) from Hugging Face — this can
take a couple of minutes. Subsequent runs use the local cache.

## API overview

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/v1/contracts/upload` | POST | Upload a contract, kicks off background analysis |
| `/api/v1/contracts/{id}/status` | GET | Poll analysis status |
| `/api/v1/contracts/{id}/analysis` | GET | Full clause breakdown + risk scores |
| `/api/v1/rag/query` | POST | Ask a natural-language question about the contract |
| `/api/v1/simulation/monte-carlo` | POST | Run the exposure simulation |
| `/api/v1/simulation/what-if` | POST | Re-score a proposed clause redline |

## Roadmap / known placeholders

- `rag_pipeline.py`'s `_compose_answer` currently returns the most relevant
  retrieved chunk rather than an LLM-synthesized answer — wire it to the
  Anthropic Messages API with the retrieved chunks as context for natural
  language answers.
- `CONTRACT_STORE` is in-memory (dict) for demo simplicity — swap for
  Postgres/SQLModel for persistence across restarts.
- Monte Carlo exposure ranges in `DEFAULT_EXPOSURE_RANGES` are illustrative
  defaults; calibrate against real deal data or let users override per
  contract via `exposure_overrides`.
