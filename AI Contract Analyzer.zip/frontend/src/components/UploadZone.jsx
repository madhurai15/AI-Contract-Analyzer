import { useCallback, useRef, useState } from "react";

function ShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 3l7 3v5.5c0 4.6-2.9 7.8-7 9.5-4.1-1.7-7-4.9-7-9.5V6l7-3Z" fill="none" stroke="currentColor" strokeWidth="1.6"/>
      <path d="m8.7 12 2.1 2.1 4.5-4.6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function DocumentIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M7 3.5h7l4 4V20.5H7z" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/>
      <path d="M14 3.5v4h4M9.5 12h5M9.5 15.5h5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="10.8" cy="10.8" r="5.8" fill="none" stroke="currentColor" strokeWidth="1.6"/>
      <path d="m15.2 15.2 4.3 4.3" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
    </svg>
  );
}

export default function UploadZone({ onFileSelected, isUploading }) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);

  const selectFile = (file) => {
    if (!file) return;
    const allowed = /\.(pdf|docx?|txt)$/i.test(file.name);
    if (!allowed) {
      alert("Please upload a PDF, DOCX, or TXT file.");
      return;
    }
    onFileSelected(file);
  };

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault();
      setIsDragging(false);
      selectFile(e.dataTransfer.files?.[0]);
    },
    [onFileSelected]
  );

  return (
    <main className="upload-page">
      <header className="landing-header">
        <div className="brand-lockup">
          <div className="brand-mark">D</div>
          <div>
            <div className="brand-name">DOCKET</div>
            <div className="brand-caption">CONTRACT INTELLIGENCE</div>
          </div>
        </div>

        <div className="header-status">
          <span className="status-dot" />
          <span>Private workspace</span>
        </div>
      </header>

      <section className="upload-hero">
        <div className="hero-copy">
          <div className="upload-eyebrow">
            <span className="eyebrow-line" /> NEW CONTRACT REVIEW
          </div>

          <h1 className="upload-title">
            Understand every clause<br />
            <em>before you sign.</em>
          </h1>

          <p className="upload-sub">
            Upload a contract and Docket will identify clauses, surface potential
            risks, estimate financial exposure, and let you ask questions using the
            document itself.
          </p>

          <div className="hero-points">
            <div className="hero-point">
              <span className="point-icon"><ShieldIcon /></span>
              <div><strong>Risk-aware</strong><span>Clause-level scoring</span></div>
            </div>
            <div className="hero-point">
              <span className="point-icon"><SearchIcon /></span>
              <div><strong>Document-grounded</strong><span>Semantic retrieval</span></div>
            </div>
            <div className="hero-point">
              <span className="point-icon"><DocumentIcon /></span>
              <div><strong>Actionable</strong><span>Exposure & redlines</span></div>
            </div>
          </div>
        </div>

        <div className="upload-card">
          <div className="upload-card-head">
            <div>
              <span className="card-kicker">START HERE</span>
              <h2>Upload your contract</h2>
            </div>
            <span className="secure-badge"><ShieldIcon /> Local processing</span>
          </div>

          <div
            className={`dropzone ${isDragging ? "dropzone--active" : ""} ${isUploading ? "dropzone--uploading" : ""}`}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => !isUploading && inputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && !isUploading && inputRef.current?.click()}
          >
            <input
              ref={inputRef}
              type="file"
              accept=".pdf,.docx,.doc,.txt"
              hidden
              onChange={(e) => selectFile(e.target.files?.[0])}
            />

            {isUploading ? (
              <>
                <span className="upload-spinner" />
                <span className="dropzone-label">Uploading contract…</span>
                <span className="dropzone-hint">Preparing it for analysis</span>
              </>
            ) : (
              <>
                <span className="dropzone-icon"><DocumentIcon /></span>
                <span className="dropzone-label">Drop your contract here</span>
                <span className="dropzone-or">or</span>
                <span className="browse-button">Browse files</span>
                <span className="dropzone-hint">PDF, DOCX or TXT · Max file size depends on your backend</span>
              </>
            )}
          </div>

          <div className="upload-card-footer">
            <span>What happens next</span>
            <div className="step-mini"><b>01</b> Extract</div>
            <div className="step-arrow">→</div>
            <div className="step-mini"><b>02</b> Analyze</div>
            <div className="step-arrow">→</div>
            <div className="step-mini"><b>03</b> Review</div>
          </div>
        </div>
      </section>

      <footer className="landing-footer">
        <span>LEGAL-BERT</span><i />
        <span>CHROMADB RAG</span><i />
        <span>MONTE CARLO EXPOSURE</span>
        <span className="footer-note">Built for contract review</span>
      </footer>
    </main>
  );
}
