import { useState } from "react";
import { askQuestion } from "../api/client";

const SUGGESTIONS = [
  "What are the termination conditions?",
  "Is there a liability cap?",
  "How is confidential information defined?",
];

export default function RagPanel({ contractId }) {
  const [question, setQuestion] = useState("");
  const [thread, setThread] = useState([]);
  const [loading, setLoading] = useState(false);

  const ask = async (q) => {
    const text = q ?? question;
    if (!text.trim() || loading) return;
    setLoading(true);
    setQuestion("");
    setThread((t) => [...t, { role: "question", text }]);
    try {
      const res = await askQuestion(contractId, text);
      setThread((t) => [...t, { role: "answer", text: res.answer, confidence: res.confidence }]);
    } catch (e) {
      setThread((t) => [...t, { role: "answer", text: "Could not retrieve an answer for that question." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rag-panel">
      <span className="clause-rationale-label">Ask the contract</span>

      <div className="rag-thread">
        {thread.length === 0 && (
          <div className="rag-suggestions">
            {SUGGESTIONS.map((s) => (
              <button key={s} className="rag-suggestion" onClick={() => ask(s)}>
                {s}
              </button>
            ))}
          </div>
        )}
        {thread.map((m, i) => (
          <div key={i} className={`rag-msg rag-msg--${m.role}`}>
            {m.text}
            {m.role === "answer" && typeof m.confidence === "number" && (
              <span className="rag-confidence">confidence {(m.confidence * 100).toFixed(0)}%</span>
            )}
          </div>
        ))}
        {loading && <div className="rag-msg rag-msg--answer rag-msg--loading">Searching clauses&hellip;</div>}
      </div>

      <form
        className="rag-input-row"
        onSubmit={(e) => {
          e.preventDefault();
          ask();
        }}
      >
        <input
          className="rag-input"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. What happens if we terminate early?"
        />
        <button className="btn-secondary" type="submit" disabled={loading}>
          Ask
        </button>
      </form>
    </div>
  );
}
