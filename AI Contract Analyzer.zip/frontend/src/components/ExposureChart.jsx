import { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ReferenceLine,
  Tooltip,
} from "recharts";
import { runMonteCarlo } from "../api/client";

export default function ExposureChart({ contractId }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    runMonteCarlo(contractId)
      .then((res) => !cancelled && setData(res))
      .catch(() => !cancelled && setError("Simulation unavailable — is analysis complete?"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [contractId]);

  if (loading) return <div className="exposure-loading">Running 10,000 simulated outcomes&hellip;</div>;
  if (error) return <div className="exposure-loading">{error}</div>;
  if (!data) return null;

  const points = data.distribution_sample.map((v, i) => ({ x: i, y: v }));

  return (
    <div className="exposure-chart">
      <div className="exposure-stats">
        <Stat label="Expected" value={data.expected_exposure} />
        <Stat label="P50" value={data.p50_exposure} />
        <Stat label="P90" value={data.p90_exposure} />
        <Stat label="P99" value={data.p99_exposure} accent />
        <Stat label="Worst case" value={data.worst_case_exposure} accent />
      </div>
      <div className="exposure-plot">
        <ResponsiveContainer width="100%" height={180}>
          <ScatterChart margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
            <XAxis dataKey="x" hide />
            <YAxis
              dataKey="y"
              tick={{ fill: "var(--slate-dim)", fontSize: 11, fontFamily: "var(--font-mono)" }}
              width={44}
              tickFormatter={(v) => `₹${v}L`}
            />
            <ReferenceLine y={data.p90_exposure} stroke="var(--risk-medium)" strokeDasharray="3 3" />
            <Tooltip
              cursor={false}
              contentStyle={{
                background: "var(--ink-soft)",
                border: "1px solid var(--line)",
                borderRadius: 3,
                fontFamily: "var(--font-mono)",
                fontSize: 12,
                color: "var(--parchment)",
              }}
              formatter={(v) => [`₹${v} lakh`, "Simulated exposure"]}
              labelFormatter={() => ""}
            />
            <Scatter data={points} fill="var(--risk-medium)" opacity={0.55} r={2.5} />
          </ScatterChart>
        </ResponsiveContainer>
      </div>
      <div className="exposure-footnote">
        {data.num_simulations.toLocaleString()} triangular-distribution draws across all flagged
        clause categories, scaled by each clause's own risk score. Amber line marks the P90 mark.
      </div>
    </div>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div className={`exposure-stat ${accent ? "exposure-stat--accent" : ""}`}>
      <span className="exposure-stat-value">₹{value.toLocaleString()}L</span>
      <span className="exposure-stat-label">{label}</span>
    </div>
  );
}
