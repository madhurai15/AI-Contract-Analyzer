import { useState } from "react";
import { runWhatIf } from "../api/client";

export default function ClauseDetail({ clause, contractId }) {
  const [draft, setDraft] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  if (!clause) {
    return (
      <div className="clause-detail clause-detail--empty">
        <span>Select a marked clause to inspect it and try a redline.</span>
      </div>
    );
  }

  const handleTest = async () => {
    if (!draft.trim()) return;
    setLoading(true);
    try {
      const res = await runWhatIf(contractId, clause.clause_id, draft);
      setResult(res);
    } catch (e) {
      setResult({ explanation: "Could not simulate this redline. Try again." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="clause-detail">
      <div className="clause-detail-head">
        <span className="clause-detail-type">{clause.clause_type}</span>
        <span className={`risk-badge risk-badge--${clause.risk_level}`}>
          {clause.risk_level} · {clause.risk_score.toFixed(0)}
        </span>
      </div>

      <p className="clause-detail-text">{clause.text}</p>

      <div className="clause-rationale">
        <span className="clause-rationale-label">Why this score</span>
        <span>{clause.risk_rationale}</span>
      </div>

      <div className="whatif-block">
        <span className="clause-rationale-label">What-if: test a redline</span>
        <textarea
          className="whatif-textarea"
          rows={4}
          placeholder="Paste your proposed replacement language here…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button className="btn-secondary" onClick={handleTest} disabled={loading}>
          {loading ? "Simulating…" : "Test redline"}
        </button>

        {result && (
          <div className="whatif-result">
            {result.explanation}
          </div>
        )}
      </div>
    </div>
  );
}
