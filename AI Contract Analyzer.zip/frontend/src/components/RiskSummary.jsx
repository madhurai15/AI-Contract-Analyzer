const RISK_COLOR = {
  low: "var(--risk-low)",
  medium: "var(--risk-medium)",
  high: "var(--risk-high)",
  critical: "var(--risk-critical)",
};

export default function RiskSummary({ analysis }) {
  const { overall_risk_score, overall_risk_level, filename, summary, missing_standard_clauses } = analysis;

  return (
    <div className="risk-summary">
      <div className="risk-summary-file">
        <span className="risk-summary-eyebrow">DOCKET NO. {analysis.contract_id.toUpperCase()}</span>
        <h2 className="risk-summary-filename">{filename}</h2>
      </div>

      <div className="risk-summary-score-block">
        <div
          className="risk-dial"
          style={{ "--dial-color": RISK_COLOR[overall_risk_level] }}
        >
          <span className="risk-dial-number">{overall_risk_score.toFixed(0)}</span>
          <span className="risk-dial-label">{overall_risk_level}</span>
        </div>
        <p className="risk-summary-text">{summary}</p>
      </div>

      {missing_standard_clauses.length > 0 && (
        <div className="missing-clauses">
          <span className="clause-rationale-label">Not found in this document</span>
          <div className="missing-chips">
            {missing_standard_clauses.map((c) => (
              <span key={c} className="missing-chip">{c}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
