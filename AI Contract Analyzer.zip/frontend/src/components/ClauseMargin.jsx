import { useState } from "react";

const RISK_COLOR = {
  low: "var(--risk-low)",
  medium: "var(--risk-medium)",
  high: "var(--risk-high)",
  critical: "var(--risk-critical)",
};

export default function ClauseMargin({ clauses, onSelectClause, activeClauseId }) {
  const [filter, setFilter] = useState("all");

  const visible =
    filter === "all" ? clauses : clauses.filter((c) => c.risk_level === filter);

  return (
    <div className="clause-margin">
      <div className="clause-margin-header">
        <span className="clause-margin-title">Marked-up clauses</span>
        <div className="clause-filters">
          {["all", "critical", "high", "medium", "low"].map((level) => (
            <button
              key={level}
              className={`filter-chip ${filter === level ? "filter-chip--active" : ""}`}
              style={level !== "all" ? { "--chip-color": RISK_COLOR[level] } : undefined}
              onClick={() => setFilter(level)}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      <div className="clause-list">
        {visible.map((clause) => (
          <button
            key={clause.clause_id}
            className={`clause-row ${activeClauseId === clause.clause_id ? "clause-row--active" : ""}`}
            style={{ "--mark-color": RISK_COLOR[clause.risk_level] }}
            onClick={() => onSelectClause(clause)}
          >
            <span className="clause-mark" aria-hidden="true" />
            <span className="clause-row-body">
              <span className="clause-row-top">
                <span className="clause-type">{clause.clause_type}</span>
                <span className="clause-score">{clause.risk_score.toFixed(0)}</span>
              </span>
              <span className="clause-snippet">{clause.text.slice(0, 140)}&hellip;</span>
            </span>
          </button>
        ))}
        {visible.length === 0 && (
          <div className="clause-empty">No clauses at this risk level.</div>
        )}
      </div>
    </div>
  );
}
