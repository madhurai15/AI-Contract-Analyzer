import { useEffect, useState } from "react";
import UploadZone from "./components/UploadZone";
import RiskSummary from "./components/RiskSummary";
import ClauseMargin from "./components/ClauseMargin";
import ClauseDetail from "./components/ClauseDetail";
import ExposureChart from "./components/ExposureChart";
import RagPanel from "./components/RagPanel";
import { uploadContract, getStatus, getAnalysis } from "./api/client";
import "./app.css";

export default function App() {
  const [contract, setContract] = useState(null); // { contract_id, filename }
  const [status, setStatus] = useState(null); // processing | completed | failed
  const [analysis, setAnalysis] = useState(null);
  const [activeClause, setActiveClause] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [rightTab, setRightTab] = useState("clause"); // clause | exposure | ask

  const handleFileSelected = async (file) => {
    setIsUploading(true);
    try {
      const res = await uploadContract(file);
      setContract(res);
      setStatus("processing");
    } catch (e) {
      alert("Upload failed. Check that the backend is running.");
    } finally {
      setIsUploading(false);
    }
  };

  // Poll status until analysis completes.
  useEffect(() => {
    if (!contract || status === "completed" || status === "failed") return;
    const interval = setInterval(async () => {
      try {
        const s = await getStatus(contract.contract_id);
        setStatus(s.status);
        if (s.status === "completed") {
          const a = await getAnalysis(contract.contract_id);
          setAnalysis(a);
        }
      } catch (e) {
        clearInterval(interval);
      }
    }, 1500);
    return () => clearInterval(interval);
  }, [contract, status]);

  if (!contract) {
    return <UploadZone onFileSelected={handleFileSelected} isUploading={isUploading} />;
  }

  if (status !== "completed") {
    return (
      <div className="processing-screen">
        <div className="processing-mark" />
        <span className="processing-label">
          {status === "failed" ? "Analysis failed." : "Reading the contract, clause by clause…"}
        </span>
      </div>
    );
  }

  return (
    <div className="workspace">
      <header className="workspace-header">
        <span className="workspace-brand">DOCKET</span>
        <button className="btn-ghost" onClick={() => window.location.reload()}>
          New review
        </button>
      </header>

      <RiskSummary analysis={analysis} />

      <div className="workspace-body">
        <ClauseMargin
          clauses={analysis.clauses}
          onSelectClause={(c) => {
            setActiveClause(c);
            setRightTab("clause");
          }}
          activeClauseId={activeClause?.clause_id}
        />

        <div className="workspace-right">
          <div className="right-tabs">
            {["clause", "exposure", "ask"].map((t) => (
              <button
                key={t}
                className={`right-tab ${rightTab === t ? "right-tab--active" : ""}`}
                onClick={() => setRightTab(t)}
              >
                {t === "clause" ? "Clause" : t === "exposure" ? "Exposure" : "Ask"}
              </button>
            ))}
          </div>

          {rightTab === "clause" && (
            <ClauseDetail clause={activeClause} contractId={contract.contract_id} />
          )}
          {rightTab === "exposure" && <ExposureChart contractId={contract.contract_id} />}
          {rightTab === "ask" && <RagPanel contractId={contract.contract_id} />}
        </div>
      </div>
    </div>
  );
}
