import axios from "axios";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";

const client = axios.create({ baseURL: API_BASE });

export const uploadContract = async (file) => {
  const form = new FormData();
  form.append("file", file);
  const { data } = await client.post("/contracts/upload", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
};

export const getStatus = async (contractId) => {
  const { data } = await client.get(`/contracts/${contractId}/status`);
  return data;
};

export const getAnalysis = async (contractId) => {
  const { data } = await client.get(`/contracts/${contractId}/analysis`);
  return data;
};

export const askQuestion = async (contractId, question) => {
  const { data } = await client.post("/rag/query", { contract_id: contractId, question });
  return data;
};

export const runMonteCarlo = async (contractId, numSimulations = 10000) => {
  const { data } = await client.post("/simulation/monte-carlo", {
    contract_id: contractId,
    num_simulations: numSimulations,
  });
  return data;
};

export const runWhatIf = async (contractId, clauseId, proposedText) => {
  const { data } = await client.post("/simulation/what-if", {
    contract_id: contractId,
    clause_id: clauseId,
    proposed_text: proposedText,
  });
  return data;
};

export default client;
