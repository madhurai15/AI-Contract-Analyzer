"""
Fine-tune a classification head on top of frozen Legal-BERT embeddings,
using the CUAD-derived train/val CSVs from prepare_cuad_data.py.

This follows the upgrade path already documented in the project README:
  "Fine-tune a classification head on top of Legal-BERT... keep this
   class's public interface (`extract_clauses`) unchanged."

Design choice: freeze Legal-BERT and train only a small MLP head on its
pooled embeddings, rather than full end-to-end fine-tuning. With ~2,600
training examples this avoids overfitting and trains in minutes on CPU,
while still being a real, evaluable, non-zero-shot classifier.

Requires internet access to huggingface.co to download
nlpaueb/legal-bert-base-uncased (~440MB) on first run -- same requirement
the existing app already has in clause_extraction.py.

Usage:
    python train_clause_classifier.py --data data/cuad/prepared --out app/ml_artifacts
"""
import argparse
import csv
import json
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset


def read_csv(path: Path):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = [(r["text"], r["label"]) for r in reader]
    return rows


@torch.no_grad()
def embed_texts(texts, tokenizer, model, device, batch_size=16):
    embeddings = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        inputs = tokenizer(batch, return_tensors="pt", truncation=True,
                            max_length=512, padding=True).to(device)
        outputs = model(**inputs)
        mask = inputs["attention_mask"].unsqueeze(-1).float()
        summed = (outputs.last_hidden_state * mask).sum(1)
        counts = mask.sum(1).clamp(min=1e-9)
        pooled = summed / counts
        pooled = torch.nn.functional.normalize(pooled, p=2, dim=1)
        embeddings.append(pooled.cpu())
        if (i // batch_size) % 10 == 0:
            print(f"  embedded {i + len(batch)}/{len(texts)}")
    return torch.cat(embeddings, dim=0)


class ClassifierHead(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, n_classes: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim, n_classes),
        )

    def forward(self, x):
        return self.net(x)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("data/cuad/prepared"))
    parser.add_argument("--out", type=Path, default=Path("app/ml_artifacts"))
    parser.add_argument("--model-name", default="nlpaueb/legal-bert-base-uncased")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--hidden-dim", type=int, default=256)
    args = parser.parse_args()

    from transformers import AutoTokenizer, AutoModel

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading {args.model_name} on {device} ...")
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    model = AutoModel.from_pretrained(args.model_name).to(device).eval()

    train_rows = read_csv(args.data / "train.csv")
    val_rows = read_csv(args.data / "val.csv")

    labels = sorted(set(l for _, l in train_rows))
    label_to_idx = {l: i for i, l in enumerate(labels)}
    print(f"Classes ({len(labels)}): {labels}")

    print("Embedding train set...")
    train_texts, train_labels = zip(*train_rows)
    X_train = embed_texts(list(train_texts), tokenizer, model, device)
    y_train = torch.tensor([label_to_idx[l] for l in train_labels])

    print("Embedding val set...")
    val_texts, val_labels = zip(*val_rows)
    X_val = embed_texts(list(val_texts), tokenizer, model, device)
    y_val = torch.tensor([label_to_idx[l] for l in val_labels])

    head = ClassifierHead(X_train.shape[1], args.hidden_dim, len(labels)).to(device)
    optimizer = torch.optim.Adam(head.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()

    train_ds = TensorDataset(X_train, y_train)
    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)

    best_val_acc = 0.0
    args.out.mkdir(parents=True, exist_ok=True)

    for epoch in range(args.epochs):
        head.train()
        total_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            logits = head(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * xb.size(0)

        head.eval()
        with torch.no_grad():
            val_logits = head(X_val.to(device))
            val_preds = val_logits.argmax(dim=1).cpu()
            val_acc = (val_preds == y_val).float().mean().item()

        print(f"epoch {epoch+1:02d}  train_loss={total_loss/len(train_ds):.4f}  val_acc={val_acc:.3f}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(head.state_dict(), args.out / "clause_classifier_head.pt")

    (args.out / "labels.json").write_text(json.dumps(labels, indent=2))
    (args.out / "config.json").write_text(json.dumps({
        "model_name": args.model_name,
        "hidden_dim": args.hidden_dim,
        "in_dim": X_train.shape[1],
        "best_val_acc": best_val_acc,
    }, indent=2))

    print(f"\nBest val accuracy: {best_val_acc:.3f}")
    print(f"Saved head weights + labels + config to {args.out}/")


if __name__ == "__main__":
    main()
