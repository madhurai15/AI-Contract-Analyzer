"""
Prepare a clause-classification training set from the real CUAD dataset.

CUAD (Contract Understanding Atticus Dataset) is distributed as a SQuAD-style
JSON: for each of 510 contracts, 41 "questions" (one per clause category) are
asked against the contract text, and each question has zero or more
human-labeled answer spans (the actual clause text a lawyer highlighted).

Source: https://github.com/TheAtticusProject/cuad (CC BY 4.0)

IMPORTANT — honest scope note:
CUAD's 41 categories do NOT line up one-to-one with this app's 13
ClauseType values. Categories like "Indemnification", "Confidentiality",
"Payment Terms", "Auto-Renewal", "Force Majeure", "Data Protection" and
"Dispute Resolution" simply don't exist in CUAD's taxonomy, so there is no
ground-truth data for them here. This script only emits training examples
for the subset of ClauseType categories that DO have a clean CUAD mapping
(see CUAD_TO_APP_LABEL below). The rest continue to rely on the existing
zero-shot approach in clause_extraction.py — that's why the final system is
a hybrid, not a full replacement.

Usage:
    python prepare_cuad_data.py --cuad-json data/cuad/CUADv1.json --out data/cuad/prepared
"""
import argparse
import json
import random
import csv
from pathlib import Path

# Only CUAD categories with an unambiguous match to an existing ClauseType.
CUAD_TO_APP_LABEL = {
    "Governing Law": "Governing Law",
    "Non-Compete": "Non-Compete",
    "Cap On Liability": "Limitation of Liability",
    "Uncapped Liability": "Limitation of Liability",
    "Termination For Convenience": "Termination",
    "Ip Ownership Assignment": "IP Assignment",
    "Joint Ip Ownership": "IP Assignment",
}

RANDOM_SEED = 13
MIN_CHARS = 40
MAX_CHARS = 2000


def load_examples(cuad_json_path: Path):
    raw = json.loads(cuad_json_path.read_text())
    positives = []  # (text, label)
    negatives = []  # (text,) -- spans from categories we're not training on / unanswered

    for doc in raw["data"]:
        for para in doc["paragraphs"]:
            for qa in para["qas"]:
                category = qa["id"].split("__")[-1]
                answers = qa.get("answers", [])
                label = CUAD_TO_APP_LABEL.get(category)

                if answers:
                    for ans in answers:
                        text = ans["text"].strip()
                        if not (MIN_CHARS <= len(text) <= MAX_CHARS):
                            continue
                        if label:
                            positives.append((text, label))
                        else:
                            # A real, human-highlighted clause, just not one of
                            # our target categories -> useful as a hard negative.
                            negatives.append((text,))
                # unanswered questions contribute no span text, skip.
    return positives, negatives


def build_dataset(positives, negatives, out_dir: Path, val_ratio: float = 0.15):
    random.seed(RANDOM_SEED)
    random.shuffle(positives)
    random.shuffle(negatives)

    # Cap negatives so "Other" doesn't swamp the real categories.
    target_labels = sorted(set(l for _, l in positives))
    per_label_counts = {l: sum(1 for _, ll in positives if ll == l) for l in target_labels}
    n_other = min(len(negatives), max(per_label_counts.values()))
    negatives = negatives[:n_other]

    rows = [(text, label) for text, label in positives] + [(text, "Other") for (text,) in negatives]
    random.shuffle(rows)

    n_val = int(len(rows) * val_ratio)
    val_rows, train_rows = rows[:n_val], rows[n_val:]

    out_dir.mkdir(parents=True, exist_ok=True)
    for name, split in (("train.csv", train_rows), ("val.csv", val_rows)):
        with open(out_dir / name, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["text", "label"])
            writer.writerows(split)

    print("Class distribution (train+val combined):")
    from collections import Counter
    counts = Counter(label for _, label in rows)
    for label, n in counts.most_common():
        print(f"  {label:30s} {n}")
    print(f"\nTotal examples: {len(rows)}  (train={len(train_rows)}, val={len(val_rows)})")
    print(f"Written to: {out_dir}/train.csv and {out_dir}/val.csv")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--cuad-json", type=Path, default=Path("data/cuad/CUADv1.json"))
    parser.add_argument("--out", type=Path, default=Path("data/cuad/prepared"))
    args = parser.parse_args()

    positives, negatives = load_examples(args.cuad_json)
    print(f"Extracted {len(positives)} positive clause spans across "
          f"{len(CUAD_TO_APP_LABEL)} mapped CUAD categories.")
    print(f"Extracted {len(negatives)} candidate negative spans "
          f"(real clauses from categories we don't train on).")
    build_dataset(positives, negatives, args.out)
