import uuid
import shutil
from datetime import datetime
from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from app.core.config import settings
from app.models.schemas import ContractUploadResponse, ContractAnalysisResponse
from app.services.document_parser import DocumentParser
from app.services.clause_extraction import ClauseExtractor
from app.services.rag_pipeline import RAGPipeline
from app.services.risk_scoring import RiskScorer

router = APIRouter(prefix="/contracts", tags=["contracts"])

# In-memory store for demo purposes. Swap for Postgres/SQLModel in production
# -- keeping the interface (get/set by contract_id) the same makes that swap
# mechanical rather than a rewrite.
CONTRACT_STORE: dict[str, dict] = {}

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt"}


@router.post("/upload", response_model=ContractUploadResponse)
async def upload_contract(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    suffix = "." + file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type '{suffix}'. Allowed: {ALLOWED_EXTENSIONS}")

    contract_id = str(uuid.uuid4())[:12]
    dest_path = settings.UPLOAD_DIR / f"{contract_id}{suffix}"

    with dest_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    parsed = DocumentParser.parse(dest_path)

    CONTRACT_STORE[contract_id] = {
        "filename": file.filename,
        "file_path": str(dest_path),
        "uploaded_at": datetime.utcnow(),
        "full_text": parsed["full_text"],
        "page_map": parsed["page_map"],
        "num_pages": parsed["num_pages"],
        "status": "processing",
        "analysis": None,
    }

    background_tasks.add_task(_run_analysis, contract_id)

    return ContractUploadResponse(
        contract_id=contract_id,
        filename=file.filename,
        uploaded_at=CONTRACT_STORE[contract_id]["uploaded_at"],
        num_pages=parsed["num_pages"],
        status="processing",
    )


def _run_analysis(contract_id: str):
    """Runs clause extraction, risk scoring, and RAG indexing in the background."""
    record = CONTRACT_STORE.get(contract_id)
    if not record:
        return
    try:
        extractor = ClauseExtractor()
        scorer = RiskScorer()
        rag = RAGPipeline()

        clauses = extractor.extract_clauses(record["full_text"], record["page_map"])
        overall_score, overall_level = scorer.score_contract(clauses)

        found_types = {c.clause_type.value for c in clauses}
        missing = [t for t in settings.RISK_CLAUSE_CATEGORIES if t not in found_types]

        rag.index_contract(contract_id, record["full_text"])

        summary = (
            f"{len(clauses)} clauses identified across {len(found_types)} categories. "
            f"Overall risk: {overall_level.value.upper()} ({overall_score}/100). "
            f"{len(missing)} standard clause type(s) not detected: {', '.join(missing) if missing else 'none'}."
        )

        record["analysis"] = ContractAnalysisResponse(
            contract_id=contract_id,
            filename=record["filename"],
            overall_risk_score=overall_score,
            overall_risk_level=overall_level,
            clauses=clauses,
            missing_standard_clauses=missing,
            summary=summary,
            analyzed_at=datetime.utcnow(),
        )
        record["status"] = "completed"
    except Exception as e:
        record["status"] = "failed"
        record["error"] = str(e)


@router.get("/{contract_id}/status")
async def get_status(contract_id: str):
    record = CONTRACT_STORE.get(contract_id)
    if not record:
        raise HTTPException(404, "Contract not found")
    return {"contract_id": contract_id, "status": record["status"]}


@router.get("/{contract_id}/analysis", response_model=ContractAnalysisResponse)
async def get_analysis(contract_id: str):
    record = CONTRACT_STORE.get(contract_id)
    if not record:
        raise HTTPException(404, "Contract not found")
    if record["status"] == "processing":
        raise HTTPException(202, "Analysis still in progress")
    if record["status"] == "failed":
        raise HTTPException(500, f"Analysis failed: {record.get('error')}")
    return record["analysis"]


@router.get("/")
async def list_contracts():
    return [
        {
            "contract_id": cid,
            "filename": r["filename"],
            "status": r["status"],
            "uploaded_at": r["uploaded_at"],
        }
        for cid, r in CONTRACT_STORE.items()
    ]


@router.delete("/{contract_id}")
async def delete_contract(contract_id: str):
    if contract_id not in CONTRACT_STORE:
        raise HTTPException(404, "Contract not found")
    RAGPipeline().delete_contract(contract_id)
    del CONTRACT_STORE[contract_id]
    return {"deleted": contract_id}
