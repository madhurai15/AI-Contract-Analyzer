from fastapi import APIRouter, HTTPException
from app.models.schemas import (
    MonteCarloRequest, MonteCarloResponse, WhatIfRequest, WhatIfResponse,
)
from app.services.monte_carlo import MonteCarloSimulator
from app.services.clause_extraction import ClauseExtractor
from app.services.risk_scoring import RiskScorer
from app.routers.contracts import CONTRACT_STORE

router = APIRouter(prefix="/simulation", tags=["simulation"])


@router.post("/monte-carlo", response_model=MonteCarloResponse)
async def run_monte_carlo(request: MonteCarloRequest):
    record = CONTRACT_STORE.get(request.contract_id)
    if not record:
        raise HTTPException(404, "Contract not found")
    if record["status"] != "completed":
        raise HTTPException(202, "Contract analysis not yet complete")

    clauses = record["analysis"].clauses
    simulator = MonteCarloSimulator()
    result = simulator.simulate(
        clauses=clauses,
        num_simulations=request.num_simulations,
        exposure_overrides=request.exposure_overrides,
    )

    return MonteCarloResponse(contract_id=request.contract_id, num_simulations=request.num_simulations, **result)


@router.post("/what-if", response_model=WhatIfResponse)
async def run_what_if(request: WhatIfRequest):
    """
    Live what-if simulator: re-scores a clause after the user edits its text,
    so they can see the risk delta of a proposed redline before sending it
    back to the counterparty. This re-runs classification + scoring on the
    proposed text only (cheap) rather than re-analyzing the whole contract.
    """
    record = CONTRACT_STORE.get(request.contract_id)
    if not record:
        raise HTTPException(404, "Contract not found")

    analysis = record.get("analysis")
    if not analysis:
        raise HTTPException(202, "Contract analysis not yet complete")

    original_clause = next((c for c in analysis.clauses if c.clause_id == request.clause_id), None)
    if not original_clause:
        raise HTTPException(404, "Clause not found in this contract's analysis")

    extractor = ClauseExtractor()
    scorer = RiskScorer()

    proposed_embedding = extractor._embed(request.proposed_text)
    # Re-use the same clause_type (the user is redlining within the same
    # clause, not changing what kind of clause it is) but re-run risk scoring
    # against the new text so keyword-based signals update.
    similarity = 1.0  # trust the original category classification for this clause
    _, proposed_score, _ = scorer.score_clause(
        clause_type=original_clause.clause_type, text=request.proposed_text, similarity=similarity
    )

    delta = round(proposed_score - original_clause.risk_score, 1)
    direction = "reduces" if delta < 0 else "increases" if delta > 0 else "does not change"
    explanation = (
        f"Proposed redline {direction} risk by {abs(delta)} points "
        f"({original_clause.risk_score} \u2192 {proposed_score}) for this "
        f"{original_clause.clause_type.value} clause."
    )

    return WhatIfResponse(
        clause_id=request.clause_id,
        original_risk_score=original_clause.risk_score,
        proposed_risk_score=proposed_score,
        delta=delta,
        explanation=explanation,
    )
