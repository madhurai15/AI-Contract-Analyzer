from fastapi import APIRouter, HTTPException
from app.models.schemas import RAGQueryRequest, RAGQueryResponse
from app.services.rag_pipeline import RAGPipeline
from app.routers.contracts import CONTRACT_STORE

router = APIRouter(prefix="/rag", tags=["rag"])


@router.post("/query", response_model=RAGQueryResponse)
async def query_contract(request: RAGQueryRequest):
    if request.contract_id not in CONTRACT_STORE:
        raise HTTPException(404, "Contract not found")

    rag = RAGPipeline()
    result = rag.query(request.contract_id, request.question)

    return RAGQueryResponse(
        question=request.question,
        answer=result["answer"],
        source_clauses=result["source_chunks"],
        confidence=result["confidence"],
    )
