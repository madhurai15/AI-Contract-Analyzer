from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ClauseType(str, Enum):
    INDEMNIFICATION = "Indemnification"
    LIMITATION_OF_LIABILITY = "Limitation of Liability"
    TERMINATION = "Termination"
    GOVERNING_LAW = "Governing Law"
    CONFIDENTIALITY = "Confidentiality"
    PAYMENT_TERMS = "Payment Terms"
    AUTO_RENEWAL = "Auto-Renewal"
    IP_ASSIGNMENT = "IP Assignment"
    NON_COMPETE = "Non-Compete"
    FORCE_MAJEURE = "Force Majeure"
    DATA_PROTECTION = "Data Protection"
    DISPUTE_RESOLUTION = "Dispute Resolution"
    OTHER = "Other"


class ExtractedClause(BaseModel):
    clause_id: str
    clause_type: ClauseType
    text: str
    start_char: int
    end_char: int
    confidence: float = Field(ge=0.0, le=1.0)
    risk_level: RiskLevel
    risk_score: float = Field(ge=0.0, le=100.0)
    risk_rationale: str
    page_number: Optional[int] = None


class ContractUploadResponse(BaseModel):
    contract_id: str
    filename: str
    uploaded_at: datetime
    num_pages: Optional[int] = None
    status: str = "processing"


class ContractAnalysisResponse(BaseModel):
    contract_id: str
    filename: str
    overall_risk_score: float = Field(ge=0.0, le=100.0)
    overall_risk_level: RiskLevel
    clauses: list[ExtractedClause]
    missing_standard_clauses: list[str]
    summary: str
    analyzed_at: datetime


class RAGQueryRequest(BaseModel):
    contract_id: str
    question: str


class RAGQueryResponse(BaseModel):
    question: str
    answer: str
    source_clauses: list[str]
    confidence: float = Field(ge=0.0, le=1.0)


class MonteCarloRequest(BaseModel):
    contract_id: str
    num_simulations: int = 10000
    # Optional overrides for exposure ranges per clause type
    exposure_overrides: Optional[dict[str, tuple[float, float]]] = None


class MonteCarloResponse(BaseModel):
    contract_id: str
    num_simulations: int
    expected_exposure: float
    p50_exposure: float
    p90_exposure: float
    p99_exposure: float
    worst_case_exposure: float
    distribution_sample: list[float]  # downsampled for charting


class WhatIfRequest(BaseModel):
    contract_id: str
    clause_id: str
    proposed_text: str


class WhatIfResponse(BaseModel):
    clause_id: str
    original_risk_score: float
    proposed_risk_score: float
    delta: float
    explanation: str
