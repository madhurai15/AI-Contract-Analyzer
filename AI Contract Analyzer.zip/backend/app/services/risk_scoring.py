"""
Rule-augmented risk scoring for extracted clauses.

Design: base risk weight per clause category (how dangerous this category
tends to be in commercial contracts) combined with red-flag keyword signals
found in the clause text itself (e.g. "unlimited liability", "sole
discretion", "perpetual"), then adjusted by classification confidence.

This is intentionally transparent/rule-based rather than a black-box model,
because for a risk tool the *rationale* matters as much as the score --
this is also what makes the "risk_rationale" field meaningful for the UI.
"""
from app.models.schemas import ClauseType, RiskLevel

# Base severity per clause category (0-100 scale), reflecting how much
# downside a poorly-drafted version of this clause typically carries.
BASE_RISK_WEIGHT: dict[ClauseType, float] = {
    ClauseType.INDEMNIFICATION: 70,
    ClauseType.LIMITATION_OF_LIABILITY: 65,
    ClauseType.TERMINATION: 45,
    ClauseType.GOVERNING_LAW: 30,
    ClauseType.CONFIDENTIALITY: 35,
    ClauseType.PAYMENT_TERMS: 40,
    ClauseType.AUTO_RENEWAL: 55,
    ClauseType.IP_ASSIGNMENT: 60,
    ClauseType.NON_COMPETE: 50,
    ClauseType.FORCE_MAJEURE: 25,
    ClauseType.DATA_PROTECTION: 55,
    ClauseType.DISPUTE_RESOLUTION: 40,
    ClauseType.OTHER: 20,
}

# Red-flag phrases that increase risk when present in a clause, with a
# short human-readable reason used in the rationale text.
RED_FLAGS: list[tuple[str, float, str]] = [
    ("unlimited liability", 20, "unlimited liability exposure"),
    ("sole discretion", 12, "one-sided discretionary power"),
    ("perpetual", 10, "perpetual / indefinite obligation"),
    ("irrevocable", 10, "irrevocable commitment"),
    ("without notice", 10, "no notice period required"),
    ("automatically renew", 12, "auto-renewal without easy opt-out"),
    ("waive", 8, "waiver of rights"),
    ("in its entirety", 5, "broad/absolute scope"),
    ("no liability", 15, "liability exclusion"),
    ("time is of the essence", 5, "strict timing obligation"),
    ("liquidated damages", 12, "pre-set penalty exposure"),
    ("exclusive", 6, "exclusivity restriction"),
    ("non-refundable", 8, "no refund pathway"),
]

# Phrases that mitigate risk (protective language) - small negative adjustment.
GREEN_FLAGS: list[tuple[str, float, str]] = [
    ("mutual", -8, "mutual/reciprocal obligation"),
    ("cap on liability", -10, "liability is capped"),
    ("reasonable notice", -6, "reasonable notice required"),
    ("commercially reasonable", -5, "qualified by reasonableness standard"),
    ("30 days", -3, "defined cure/notice period"),
]


class RiskScorer:
    def score_clause(self, clause_type: ClauseType, text: str, similarity: float) -> tuple[RiskLevel, float, str]:
        text_lower = text.lower()
        base = BASE_RISK_WEIGHT.get(clause_type, 20)

        triggered_flags = []
        adjustment = 0.0
        for phrase, weight, reason in RED_FLAGS:
            if phrase in text_lower:
                adjustment += weight
                triggered_flags.append(f"+{reason}")
        for phrase, weight, reason in GREEN_FLAGS:
            if phrase in text_lower:
                adjustment += weight
                triggered_flags.append(f"-{reason}")

        # Confidence discount: low classification confidence pulls score
        # toward a neutral midpoint rather than trusting the raw category weight.
        confidence_factor = 0.5 + 0.5 * similarity  # similarity in [0.55, 1.0] roughly
        raw_score = base * confidence_factor + adjustment
        score = max(0.0, min(100.0, raw_score))

        if score >= 75:
            level = RiskLevel.CRITICAL
        elif score >= 55:
            level = RiskLevel.HIGH
        elif score >= 30:
            level = RiskLevel.MEDIUM
        else:
            level = RiskLevel.LOW

        if triggered_flags:
            rationale = f"{clause_type.value} clause; signals: " + ", ".join(triggered_flags)
        else:
            rationale = f"{clause_type.value} clause; standard language, no red-flag phrases detected"

        return level, round(score, 1), rationale

    def score_contract(self, clauses: list) -> tuple[float, RiskLevel]:
        if not clauses:
            return 0.0, RiskLevel.LOW
        # Weight overall score toward the highest-risk clauses (max) blended
        # with the average, so one catastrophic clause can't be diluted away
        # by a dozen boilerplate ones, but a single clause also can't be the
        # *only* signal.
        scores = [c.risk_score for c in clauses]
        avg_score = sum(scores) / len(scores)
        max_score = max(scores)
        overall = 0.4 * avg_score + 0.6 * max_score
        overall = round(min(100.0, overall), 1)

        if overall >= 75:
            level = RiskLevel.CRITICAL
        elif overall >= 55:
            level = RiskLevel.HIGH
        elif overall >= 30:
            level = RiskLevel.MEDIUM
        else:
            level = RiskLevel.LOW
        return overall, level
