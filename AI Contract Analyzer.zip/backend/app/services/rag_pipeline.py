"""
Retrieval-Augmented Generation over a single contract.

- Chunks the contract text (separately from clause segmentation -- RAG chunks
  are smaller/overlapping for better retrieval granularity).
- Embeds chunks with a lightweight sentence-transformer (fast, good enough
  for retrieval; Legal-BERT embeddings are reserved for clause
  classification where domain vocabulary matters more).
- Stores per-contract in a ChromaDB collection namespaced by contract_id, so
  multiple contracts don't bleed into each other's retrieval results.
- `answer_question` retrieves top-k chunks and composes a grounded answer.
  Swap `_compose_answer` for a call to an LLM (Anthropic API) for
  higher-quality synthesis -- the retrieval plumbing stays the same.
"""
import chromadb
from sentence_transformers import SentenceTransformer
from app.core.config import settings


class RAGPipeline:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init()
        return cls._instance

    def _init(self):
        self.embedder = SentenceTransformer(settings.EMBEDDING_MODEL)
        self.client = chromadb.PersistentClient(path=str(settings.CHROMA_DIR))

    def _collection_name(self, contract_id: str) -> str:
        return f"contract_{contract_id}"

    @staticmethod
    def _chunk_text(text: str) -> list[str]:
        size, overlap = settings.CHUNK_SIZE, settings.CHUNK_OVERLAP
        chunks = []
        start = 0
        while start < len(text):
            end = start + size
            chunks.append(text[start:end])
            start = end - overlap
        return [c.strip() for c in chunks if len(c.strip()) > 20]

    def index_contract(self, contract_id: str, full_text: str) -> int:
        """Chunk + embed + store a contract's text. Returns number of chunks indexed."""
        collection = self.client.get_or_create_collection(self._collection_name(contract_id))
        chunks = self._chunk_text(full_text)
        if not chunks:
            return 0

        embeddings = self.embedder.encode(chunks, show_progress_bar=False).tolist()
        ids = [f"{contract_id}_chunk_{i}" for i in range(len(chunks))]
        collection.upsert(ids=ids, documents=chunks, embeddings=embeddings)
        return len(chunks)

    def query(self, contract_id: str, question: str, top_k: int = 4) -> dict:
        collection = self.client.get_or_create_collection(self._collection_name(contract_id))
        question_embedding = self.embedder.encode([question]).tolist()
        results = collection.query(query_embeddings=question_embedding, n_results=top_k)

        retrieved_chunks = results["documents"][0] if results["documents"] else []
        distances = results["distances"][0] if results.get("distances") else []

        answer, confidence = self._compose_answer(question, retrieved_chunks, distances)
        return {
            "answer": answer,
            "source_chunks": retrieved_chunks,
            "confidence": confidence,
        }

    @staticmethod
    def _compose_answer(question: str, chunks: list[str], distances: list[float]) -> tuple[str, float]:
        """
        Placeholder synthesis: returns the most relevant chunk(s) with light
        framing. Replace this with a real LLM call (e.g. Anthropic Messages
        API with the retrieved chunks as context) for natural-language
        answers -- the retrieval step above already gives you grounded,
        citation-able context to pass in.
        """
        if not chunks:
            return "No relevant clause found in this contract for that question.", 0.0

        # Chroma returns cosine/L2 distance depending on config; lower = more similar.
        # Convert to a rough 0-1 confidence for display purposes.
        top_distance = distances[0] if distances else 1.0
        confidence = max(0.0, min(1.0, 1.0 - top_distance))

        combined = " ".join(chunks[:2])
        answer = f"Based on the contract text, the most relevant passage states: \u201c{combined[:600]}\u201d"
        return answer, round(confidence, 2)

    def delete_contract(self, contract_id: str):
        try:
            self.client.delete_collection(self._collection_name(contract_id))
        except Exception:
            pass
