"""
Clause segmentation + classification.

Approach -- now a HYBRID of fine-tuned and zero-shot, deliberately explicit
about what's real vs. approximate:

1. Segment contract text into candidate clauses (paragraph/heading based).
2. Embed each candidate clause with Legal-BERT (nlpaueb/legal-bert-base-uncased),
   mean-pooled over the last hidden state.
3. Classify:
   a. FINE-TUNED PATH -- for the categories that have real ground-truth
      labels in the CUAD dataset (Governing Law, Non-Compete, Limitation of
      Liability, Termination, IP Assignment -- see
      scripts/prepare_cuad_data.py for the exact mapping and why only these),
      a small classification head trained on ~2,600 CUAD-derived examples
      (scripts/train_clause_classifier.py) scores the clause. This is loaded
      from app/ml_artifacts/ if present.
   b. ZERO-SHOT FALLBACK -- CUAD's 41 categories don't cover everything this
      app cares about (Indemnification, Confidentiality, Payment Terms,
      Auto-Renewal, Force Majeure, Data Protection, Dispute Resolution have
      no CUAD ground truth at all). For these, and as a fallback if no
      trained head is present, we fall back to the original cosine-similarity
      match against hand-written prototype descriptions.
   Both paths score every candidate clause and the higher-confidence result
   wins, so a fine-tuned category doesn't lose to a low-confidence zero-shot
   guess and vice versa.

Run `python scripts/prepare_cuad_data.py` then `python
scripts/train_clause_classifier.py` to (re)produce the fine-tuned head.
"""
import json
import re
import uuid
from pathlib import Path

import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoModel
from app.core.config import settings
from app.models.schemas import ExtractedClause, ClauseType, RiskLevel
from app.services.risk_scoring import RiskScorer

ML_ARTIFACTS_DIR = Path(__file__).resolve().parent.parent / "ml_artifacts"


class ClassifierHead(nn.Module):
    """Must match the architecture in scripts/train_clause_classifier.py exactly."""

    def __init__(self, in_dim: int, hidden_dim: int, n_classes: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim, n_classes),
        )

    def forward(self, x):
        return self.net(x)

# Prototype descriptions used for zero-shot similarity matching.
# These are short canonical definitions of each clause type.
CLAUSE_PROTOTYPES = {
    ClauseType.INDEMNIFICATION: "party shall indemnify, defend and hold harmless the other party from claims, losses, damages, liabilities and expenses",
    ClauseType.LIMITATION_OF_LIABILITY: "in no event shall either party be liable for indirect, incidental, special or consequential damages, liability is capped",
    ClauseType.TERMINATION: "this agreement may be terminated by either party upon written notice, termination for convenience or for cause",
    ClauseType.GOVERNING_LAW: "this agreement shall be governed by and construed in accordance with the laws of the jurisdiction",
    ClauseType.CONFIDENTIALITY: "each party agrees to keep confidential information secret and not disclose it to third parties",
    ClauseType.PAYMENT_TERMS: "payment shall be due within a specified number of days of invoice, late payment interest, fees and pricing",
    ClauseType.AUTO_RENEWAL: "this agreement shall automatically renew for successive terms unless either party provides notice of non-renewal",
    ClauseType.IP_ASSIGNMENT: "all intellectual property, inventions, work product created shall be owned by and assigned to",
    ClauseType.NON_COMPETE: "party shall not engage in competing business activities or solicit customers or employees during and after the term",
    ClauseType.FORCE_MAJEURE: "neither party shall be liable for delay or failure to perform due to causes beyond reasonable control such as acts of god",
    ClauseType.DATA_PROTECTION: "party shall comply with applicable data protection and privacy laws regarding processing of personal data",
    ClauseType.DISPUTE_RESOLUTION: "any dispute arising out of this agreement shall be resolved through arbitration or litigation in a specified venue",
}


class ClauseExtractor:
    _instance = None

    def __new__(cls):
        # Simple singleton so the model is loaded once per process, not per request.
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_model()
        return cls._instance

    def _load_model(self):
        self.tokenizer = AutoTokenizer.from_pretrained(settings.LEGAL_BERT_MODEL)
        self.model = AutoModel.from_pretrained(settings.LEGAL_BERT_MODEL)
        self.model.eval()
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model.to(self.device)

        # Pre-compute prototype embeddings once at load time.
        self.prototype_embeddings = {
            clause_type: self._embed(text)
            for clause_type, text in CLAUSE_PROTOTYPES.items()
        }
        self.risk_scorer = RiskScorer()

        # Optionally load the fine-tuned head trained on CUAD-derived data.
        # Falls back gracefully to zero-shot-only if artifacts aren't present
        # (e.g. training hasn't been run yet).
        self.fine_tuned_head = None
        self.fine_tuned_labels: list[str] = []
        self._load_fine_tuned_head()

    def _load_fine_tuned_head(self):
        head_path = ML_ARTIFACTS_DIR / "clause_classifier_head.pt"
        labels_path = ML_ARTIFACTS_DIR / "labels.json"
        config_path = ML_ARTIFACTS_DIR / "config.json"
        if not (head_path.exists() and labels_path.exists() and config_path.exists()):
            return

        config = json.loads(config_path.read_text())
        self.fine_tuned_labels = json.loads(labels_path.read_text())
        head = ClassifierHead(
            in_dim=config["in_dim"],
            hidden_dim=config["hidden_dim"],
            n_classes=len(self.fine_tuned_labels),
        )
        head.load_state_dict(torch.load(head_path, map_location=self.device))
        head.eval()
        head.to(self.device)
        self.fine_tuned_head = head

    @torch.no_grad()
    def _classify_fine_tuned(self, embedding: torch.Tensor):
        """Returns (ClauseType | None, confidence) using the trained head, or
        (None, 0.0) if no head is loaded or the top prediction is 'Other'."""
        if self.fine_tuned_head is None:
            return None, 0.0
        logits = self.fine_tuned_head(embedding.unsqueeze(0))
        probs = torch.softmax(logits, dim=1).squeeze(0)
        top_idx = int(probs.argmax().item())
        label = self.fine_tuned_labels[top_idx]
        confidence = float(probs[top_idx].item())
        if label == "Other":
            return None, confidence
        return ClauseType(label), confidence

    @torch.no_grad()
    def _embed(self, text: str) -> torch.Tensor:
        inputs = self.tokenizer(
            text, return_tensors="pt", truncation=True, max_length=512, padding=True
        ).to(self.device)
        outputs = self.model(**inputs)
        # Mean pooling over token embeddings, masked by attention.
        mask = inputs["attention_mask"].unsqueeze(-1).float()
        summed = (outputs.last_hidden_state * mask).sum(1)
        counts = mask.sum(1).clamp(min=1e-9)
        pooled = summed / counts
        return torch.nn.functional.normalize(pooled, p=2, dim=1).squeeze(0)

    @staticmethod
    def _segment(full_text: str) -> list[dict]:
        """Split contract into candidate clause blocks.

        Heuristic: split on numbered/lettered section headers or blank-line
        separated paragraphs, then drop short boilerplate (< 40 chars).
        """
        pattern = re.compile(
            r"(?=\n\s*(?:\d+\.\d*|\d+\)|[A-Z]{2,}[\.\)]|Section\s+\d+|Article\s+\d+))",
            re.MULTILINE,
        )
        raw_blocks = pattern.split(full_text) if pattern.search(full_text) else full_text.split("\n\n")

        segments = []
        cursor = 0
        for block in raw_blocks:
            block_stripped = block.strip()
            start = full_text.find(block_stripped, cursor) if block_stripped else -1
            if start == -1:
                start = cursor
            end = start + len(block_stripped)
            cursor = max(cursor, end)
            if len(block_stripped) >= 40:
                segments.append({"text": block_stripped, "start_char": start, "end_char": end})
        return segments

    def extract_clauses(self, full_text: str, page_map: list[dict] | None = None) -> list[ExtractedClause]:
        segments = self._segment(full_text)
        clauses: list[ExtractedClause] = []

        for seg in segments:
            embedding = self._embed(seg["text"])

            # Zero-shot path (always available).
            zs_type, zs_score = None, -1.0
            for clause_type, proto_emb in self.prototype_embeddings.items():
                sim = torch.dot(embedding, proto_emb).item()
                if sim > zs_score:
                    zs_type, zs_score = clause_type, sim

            # Fine-tuned path (only for categories with real CUAD ground truth).
            ft_type, ft_score = self._classify_fine_tuned(embedding)

            # Prefer whichever path is more confident. Confidences aren't on
            # an identical scale (softmax prob vs. cosine similarity) but
            # both are bounded [0, 1] and this keeps the interface simple;
            # see README for a note on calibrating these against each other.
            if ft_type is not None and ft_score >= zs_score:
                best_type, best_score, source = ft_type, ft_score, "fine_tuned"
            else:
                best_type, best_score, source = zs_type, zs_score, "zero_shot"

            # Similarity/confidence threshold below which we don't confidently
            # tag a category.
            if best_score < 0.55:
                continue

            risk_level, risk_score, rationale = self.risk_scorer.score_clause(
                clause_type=best_type, text=seg["text"], similarity=best_score
            )
            source_label = "fine-tuned classifier" if source == "fine_tuned" else "zero-shot similarity"
            rationale = f"{rationale} [classified via {source_label}]"

            page_number = self._page_for_offset(seg["start_char"], page_map) if page_map else None

            clauses.append(
                ExtractedClause(
                    clause_id=str(uuid.uuid4())[:8],
                    clause_type=best_type,
                    text=seg["text"][:2000],  # cap stored text length
                    start_char=seg["start_char"],
                    end_char=seg["end_char"],
                    confidence=round(min(max(best_score, 0.0), 1.0), 3),
                    risk_level=risk_level,
                    risk_score=risk_score,
                    risk_rationale=rationale,
                    page_number=page_number,
                )
            )
        return clauses

    @staticmethod
    def _page_for_offset(offset: int, page_map: list[dict]) -> int | None:
        for page in page_map:
            if page["start_char"] <= offset <= page["end_char"]:
                return page["page_number"]
        return None
