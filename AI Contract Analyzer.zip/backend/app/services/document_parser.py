"""
Extracts raw text (and rough page boundaries) from uploaded contract files.
Supports PDF and DOCX. Extend here for .txt or scanned/OCR PDFs later.
"""
from pathlib import Path
from pypdf import PdfReader
import docx


class DocumentParser:
    @staticmethod
    def parse(file_path: Path) -> dict:
        suffix = file_path.suffix.lower()
        if suffix == ".pdf":
            return DocumentParser._parse_pdf(file_path)
        elif suffix in (".docx", ".doc"):
            return DocumentParser._parse_docx(file_path)
        elif suffix == ".txt":
            return DocumentParser._parse_txt(file_path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")

    @staticmethod
    def _parse_pdf(file_path: Path) -> dict:
        reader = PdfReader(str(file_path))
        pages = []
        full_text_parts = []
        offset = 0
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            pages.append({
                "page_number": i + 1,
                "start_char": offset,
                "end_char": offset + len(text),
            })
            full_text_parts.append(text)
            offset += len(text) + 1  # +1 for the joining newline
        return {
            "full_text": "\n".join(full_text_parts),
            "num_pages": len(reader.pages),
            "page_map": pages,
        }

    @staticmethod
    def _parse_docx(file_path: Path) -> dict:
        d = docx.Document(str(file_path))
        full_text = "\n".join(p.text for p in d.paragraphs)
        return {
            "full_text": full_text,
            "num_pages": None,  # DOCX has no fixed pagination pre-render
            "page_map": [],
        }

    @staticmethod
    def _parse_txt(file_path: Path) -> dict:
        full_text = file_path.read_text(encoding="utf-8", errors="ignore")
        return {"full_text": full_text, "num_pages": None, "page_map": []}
