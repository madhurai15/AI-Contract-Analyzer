"""
Monte Carlo probabilistic financial exposure simulator.

This is the differentiating feature flagged as genuinely absent from
commercial contract-review tools: instead of a single deterministic risk
score, simulate a distribution of possible financial outcomes per clause
category and aggregate them, so a user can see P50/P90/P99 exposure and a
worst-case tail rather than one opaque number.

Each risk-bearing clause category gets a triangular distribution
(min, mode, max) for potential financial exposure in INR (lakhs), which can
be overridden per-contract via the API (e.g. if the user knows the actual
contract value and wants to scale exposure ranges accordingly).
"""
import numpy as np
from app.models.schemas import ExtractedClause, ClauseType

# Default exposure ranges (in INR lakhs) per clause category:
# (min, most_likely, max) -- used to parameterize a triangular distribution.
# These are illustrative defaults for a mid-size commercial contract and are
# meant to be overridden with real historical/legal-counsel data in a
# production deployment.
DEFAULT_EXPOSURE_RANGES: dict[ClauseType, tuple[float, float, float]] = {
    ClauseType.INDEMNIFICATION: (5, 25, 150),
    ClauseType.LIMITATION_OF_LIABILITY: (2, 15, 80),
    ClauseType.TERMINATION: (1, 5, 30),
    ClauseType.GOVERNING_LAW: (0, 2, 10),
    ClauseType.CONFIDENTIALITY: (1, 8, 50),
    ClauseType.PAYMENT_TERMS: (0.5, 3, 20),
    ClauseType.AUTO_RENEWAL: (1, 6, 25),
    ClauseType.IP_ASSIGNMENT: (3, 20, 100),
    ClauseType.NON_COMPETE: (2, 10, 40),
    ClauseType.FORCE_MAJEURE: (0, 1, 15),
    ClauseType.DATA_PROTECTION: (2, 12, 60),  # e.g. DPDP Act penalty exposure
    ClauseType.DISPUTE_RESOLUTION: (0.5, 4, 20),
    ClauseType.OTHER: (0, 1, 5),
}


class MonteCarloSimulator:
    def simulate(
        self,
        clauses: list[ExtractedClause],
        num_simulations: int = 10000,
        exposure_overrides: dict[str, tuple[float, float]] | None = None,
        seed: int | None = None,
    ) -> dict:
        rng = np.random.default_rng(seed)

        if not clauses:
            zeros = [0.0] * min(num_simulations, 500)
            return {
                "expected_exposure": 0.0, "p50_exposure": 0.0, "p90_exposure": 0.0,
                "p99_exposure": 0.0, "worst_case_exposure": 0.0, "distribution_sample": zeros,
            }

        total_samples = np.zeros(num_simulations)

        for clause in clauses:
            low, mode, high = DEFAULT_EXPOSURE_RANGES.get(clause.clause_type, (0, 1, 5))

            # Optional per-category override (min, max) from the API request;
            # keep the same mode ratio position within the new range.
            if exposure_overrides and clause.clause_type.value in exposure_overrides:
                new_low, new_high = exposure_overrides[clause.clause_type.value]
                ratio = (mode - low) / (high - low) if high > low else 0.5
                low, high = new_low, new_high
                mode = low + ratio * (high - low)

            if high <= low:
                high = low + 0.01

            # Scale the exposure draw by the clause's own risk_score (0-100)
            # so a low-risk-scored clause of a high-risk *category* still
            # contributes less to the tail than a red-flagged one.
            severity_multiplier = 0.4 + 0.012 * clause.risk_score  # ranges ~0.4x to ~1.6x

            draws = rng.triangular(low, mode, high, size=num_simulations) * severity_multiplier
            total_samples += draws

        expected = float(np.mean(total_samples))
        p50 = float(np.percentile(total_samples, 50))
        p90 = float(np.percentile(total_samples, 90))
        p99 = float(np.percentile(total_samples, 99))
        worst = float(np.max(total_samples))

        # Downsample for charting so the API response isn't 10k floats.
        sample_idx = rng.choice(num_simulations, size=min(500, num_simulations), replace=False)
        distribution_sample = [round(float(x), 2) for x in total_samples[sample_idx]]

        return {
            "expected_exposure": round(expected, 2),
            "p50_exposure": round(p50, 2),
            "p90_exposure": round(p90, 2),
            "p99_exposure": round(p99, 2),
            "worst_case_exposure": round(worst, 2),
            "distribution_sample": distribution_sample,
        }
