"""
Central configuration for the AI Contract Risk Analyzer backend.
All tunables live here so services never hardcode paths / model names.
"""
from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    # --- General ---
    APP_NAME: str = "AI Contract Risk Analyzer"
    API_V1_PREFIX: str = "/api/v1"

    # --- Storage ---
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
    UPLOAD_DIR: Path = BASE_DIR / "data" / "uploads"
    CHROMA_DIR: Path = BASE_DIR / "chroma_data"

    # --- Models ---
    # Legal-BERT for clause classification / embeddings context
    LEGAL_BERT_MODEL: str = "nlpaueb/legal-bert-base-uncased"
    # Lightweight sentence embedding model used for the RAG vector store
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"

    # --- Chunking (for RAG) ---
    CHUNK_SIZE: int = 500
    CHUNK_OVERLAP: int = 75

    # --- Risk scoring ---
    RISK_CLAUSE_CATEGORIES: list[str] = [
        "Indemnification",
        "Limitation of Liability",
        "Termination",
        "Governing Law",
        "Confidentiality",
        "Payment Terms",
        "Auto-Renewal",
        "IP Assignment",
        "Non-Compete",
        "Force Majeure",
        "Data Protection",
        "Dispute Resolution",
    ]

    # --- CORS ---
    ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://frontend:3000",
    ]

    class Config:
        env_file = ".env"


settings = Settings()
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
settings.CHROMA_DIR.mkdir(parents=True, exist_ok=True)
